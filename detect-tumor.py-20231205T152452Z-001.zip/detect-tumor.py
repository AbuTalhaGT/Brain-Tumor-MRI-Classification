# import matplotlib.pyplot as plt
import numpy as np
# import pandas as pd
# import seaborn as sns
import cv2
# import tensorflow as tf
# from tensorflow.keras.preprocessing.image import ImageDataGenerator
# from sklearn.metrics import accuracy_score
# from sklearn.metrics import confusion_matrix, ConfusionMatrixDisplay
# from tqdm import tqdm
# import os
# from sklearn.utils import shuffle
# from tensorflow.keras.layers import Conv2D, MaxPooling2D, Dropout, AveragePooling2D
# from tensorflow.keras.layers import Conv2D, MaxPooling2D, Flatten, Dense, Dropout, BatchNormalization
# from keras.models import Sequential
# from keras.layers import Dense, Activation, Flatten
# from sklearn.model_selection import train_test_split
# from tensorflow.keras.applications import EfficientNetB0
# from tensorflow.keras.callbacks import EarlyStopping, ReduceLROnPlateau, TensorBoard, ModelCheckpoint
# from sklearn.metrics import classification_report,confusion_matrix
# import ipywidgets as widgets
# from keras.regularizers import l2
# import io
# from PIL import Image
# from keras.utils import to_categorical
# from IPython.display import display,clear_output
# from warnings import filterwarnings
# from tensorflow.keras.applications import VGG16
from tensorflow.keras.applications import ResNet50
# from tensorflow.keras.applications import InceptionV3


import tensorflow as tf
from tensorflow.keras import layers, models
import json
import sys

from tensorflow.keras.models import load_model

def freeze(model):
    """Freeze model weights in every layer."""
    for layer in model.layers:
        layer.trainable = False
        if isinstance(layer, models.Model):
            freeze(layer)


# base_model = ResNet50(include_top=False, weights='imagenet', input_shape=(224, 224, 3))
# for layer in base_model.layers:
#     layer.trainable = False
# model = models.Sequential()
# model.add(base_model)
# model.add(layers.Flatten())
# model.add(layers.Dense(256, activation='relu'))
# model.add(layers.Dropout(0.5))
# model.add(layers.Dense(4, activation='softmax'))

# freeze(model)
# model.load_weights('newinferenceWithFreezeModel (7).h5')

model = load_model("newinferenceWithFreezeModel (7).h5")     # in case of freeze of network | .save() with weights and architecture
def predict_class(model, img_path):
    class_names = ['Glioma Tumor', 'No Tumor', 'Meningioma Tumor', 'Pituitary Tumor']
    img = cv2.imread(img_path)
    img = cv2.resize(img, (224, 224))
    img = np.reshape(img, (1,224,224,3))

    prediction = model.predict(img)
    # probability = prediction[0]
    # max_out = probability[prediction.argmax()]
    # print(f"Expected tumor class: {class_names[prediction.argmax()]}")
    print(class_names[prediction.argmax()]) #, max_out])


image = sys.argv[1]
predict_class(model, image)