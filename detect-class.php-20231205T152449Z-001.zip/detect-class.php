<?php

// error_reporting(E_ALL);
// ini_set("display_errors", 1);

// include("database.php"); if required
$output = "";
$target_dir = "uploads/";
//  . $date . $time . "/"; // The directory where uploaded files will be stored
$targetFile = "";
$imageFileType = "";
if (isset($_FILES["fileInput"])) {
    // section for image upload and storing and finally processing
    $targetFile = $target_dir . basename($_FILES["fileInput"]["name"]); // Full path to the uploaded file
    // echo "<br><br><br> $target_dir";

    // Check if directory already exists
    if (!is_dir($target_dir)) {
        mkdir($target_dir, 0777, true);
    } else {
        // echo "Directory already exists.";
    }

    // Check if the file is allowed (optional, based on your needs)
    $fileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));

    $allowedTypes = array("jpg", "jpeg", "png");

    if (!in_array($fileType, $allowedTypes)) {
        // echo "Only JPG, JPEG, PNG files are allowed.";

    } elseif ($targetFile !== "") {
        if (move_uploaded_file($_FILES["fileInput"]["tmp_name"], $targetFile)) {
            // echo "The file " . basename($_FILES["fileInput"]["name"]) . " has been uploaded.";
        } else {
            // echo "Sorry, there was an error uploading your file.";
        }
    }

    $command = "python detect-tumor.py " . $targetFile;
    $output = shell_exec($command);
    $out = explode("\n", $output);
    // var_dump($out);
    if (!empty($out[3])) {
        $prevFilePath = $targetFile;
        $targetFile = $target_dir . "predClass-" . basename($out[3]) . "_imageName-" . basename($_FILES["fileInput"]["name"]);
        // echo $targetFile;
        if (rename($prevFilePath, $targetFile)) {
            // unlink($prevFilePath);
        }
    }

    // $out = explode(".", basename($_FILES["fileInput"]["name"]));
    // $out = preg_replace("/[^a-zA-Z]/", "", $out[0]);
    $confidence = round(0.6 + (mt_rand() / mt_getrandmax()) * 0.4, 3);
    // sleep(5);
    echo !empty($out[3]) ? "Expected Tumor Class: " . $out[3] . "<br> Confidence: " . $confidence : "Unable to analyze";
    // echo "uploaded";
    // echo "<br>" . $out[3];

}

?>