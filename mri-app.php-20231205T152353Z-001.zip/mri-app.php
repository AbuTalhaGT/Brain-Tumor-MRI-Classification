<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detect Tumor</title>
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>

    <!-- fevicon icon -->
    <link rel="icon" href="mri_icon.jpeg" type="image/x-icon">
    <link rel="shortcut icon" href="mri_icon.jpeg" type="image/x-icon">
    
    <!-- bootstrap cnd -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL"
        crossorigin="anonymous"></script>

    <style>
        .box {
            /* border: 2px solid black; */
            border-radius: 0.4em;
        }

        .spinner-border {
            height: 20px;
            width: 20px;
        }
    </style>
</head>

<body>
    <div class="container shadow p-3 mb-5 bg-body-tertiary mt-4 p-5">

        <h1 style="text-align: center;">MRI APP</h1>

        <div class="">
            <p> The Web app is dedicated to predict 3 tumor classes and a no tumor class based on the brain MRI image.
                The classes are listed below: <br>
                1. Glioma Tumor <br>
                2. Meningioma Tumor <br>
                3. Pituitary Tumor <br>
                4. No Tumor <br>
                <hr>
        </div>
        <!--bs class rounded-3 border border-3 -->
        <div class="row ">

            <div class="col-4 col-sm-12 col-lg-4 col-xl-4 mb-3">
                <form id="uploadMRI" enctype="multipart/form-data">

                    <h6 for="mri" class="form-label">Upload Brain MRI image:</h6>
                    <input id="mri" type="file" accept="image" name="mri" class="form-control"
                        aria-describedby="imageHelp" onchange="loadFile(event);">
                    <div id="imageHelp" class="form-text">Image format: '.jpg', '.jpeg', '.png'</div>
                    <div>
                        <button type="button" id="analyze" name="analyze" class="btn btn-primary"
                            style="width: 150px; margin-top: 20px;" onclick="uploadFile();">Analyze</button>
                    </div>
            </div>
            <div class="col-2 col-lg-1 mb-3"></div>
            <div class="col-6 col-sm-12 col-lg-6 col-xl-6 mb-3">

                <div>
                    <h6>Uploaded Image</h6>
                    <div class="rounded-3 border border-3" style="height: 360px; width: 480px; text-align: center; background-color: #F5FAFF">
                        <img id="output" height="350px" width="470px"
                            style="display: none; padding: 5px; margin-left: auto; margin-right: auto;">
                    </div>
                </div>

                <!-- <label>Result:</label> -->

                <strong><label id="mri-result"></label></strong>
            </div>
            </form>

        </div>
    </div>

    <script>
        function uploadFile() {
            var fileInput = document.getElementById("mri");
            var loading = '<div class="spinner-border" role="status"> <span class="visually-hidden">Loading...</span> </div> Analyzing...';
            // check if a file is selected
            if (fileInput.files.length === 0) {
                alert('Please select a file before analyzing');
            } else {
                console.log(fileInput.files[0]);
                // buttonLoad = document.getElementById
                $("#analyze").html(loading);
                $("#analyze").prop("disabled", true);
                // buttonLoad.html(load);

                var formData = new FormData();
                formData.append('fileInput', fileInput.files[0]);

                $.ajax(
                    {
                        url: 'detect-class.php',
                        type: 'POST',
                        data: formData,
                        contentType: false,
                        processData: false,
                        success: function (response) {
                            $('#mri-result').html(response);
                            $("#analyze").text("Analyze");
                            $("#analyze").prop("disabled", false);
                        },
                        error: function () {
                            alert('Error uploading file');
                            $("#analyze").text("Analyze");
                            $("#analyze").prop("disabled", false);
                        },
                    }
                );

            }

        }

        var loadFile = function (event) {
            var reader = new FileReader();
            reader.onload = function () {
                var output = document.getElementById("output");
                output.src = reader.result;
            };

            $('#output').show();
            reader.readAsDataURL(event.target.files[0]);
        };

    </script>


</body>

</html>